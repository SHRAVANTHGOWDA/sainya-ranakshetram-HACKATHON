#include <iostream>
#include <stdlib.h>
using namespace std;
int main(void)
{
  int arr[10];

  int num = 100,i;

  // cout << "Enter the count of numbers? ";
//cin >> num;

  for (i = 0; i < num; i++)
  {
    //cout << "Enter a number to be stored: ";
   // cin >> arr_num;
    arr[i]= rand();
  }
  return 0;
}